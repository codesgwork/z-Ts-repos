import { User } from './User';

const user = new User();

console.log(user);
